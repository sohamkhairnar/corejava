package com.gvacharya.expressionstatement;

public class PrintExpressionMain {
	
	public static void main(String[] args) {
	PrintExpression printExpression = new PrintExpression();
	
	printExpression.printExpression("",3);
	
	}
}
