package com.gvacharya.factorial;



public class MainRecursiveFactorial {
	
public static void main(String[] args) {
		
		RecursiveFactorial addition = new RecursiveFactorial();
		
		System.out.println(addition.add(5));
	}
}
