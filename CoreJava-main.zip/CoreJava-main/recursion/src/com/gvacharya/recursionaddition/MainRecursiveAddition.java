package com.gvacharya.recursionaddition;

public class MainRecursiveAddition {

	public static void main(String[] args) {
		
		RecursiveAddition addition = new RecursiveAddition();
		
		System.out.println(addition.add(5));
	}
}
