/**
 * 
 */
/**
 * 
 */
module stringassignment {
}