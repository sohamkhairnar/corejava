package com.gvacharya.interfaces.lambdaexpression;

@FunctionalInterface
public interface ArithematicOperation {

	
	int Operation(int number1, int number2);
}
