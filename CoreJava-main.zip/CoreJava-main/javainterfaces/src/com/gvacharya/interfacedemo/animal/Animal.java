package com.gvacharya.interfacedemo.animal;

public interface Animal {

	String makenoise(String noises);
	
	
}
