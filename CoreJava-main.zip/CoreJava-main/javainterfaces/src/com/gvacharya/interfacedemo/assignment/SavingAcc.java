package com.gvacharya.interfacedemo.assignment;

@FunctionalInterface
public interface SavingAcc {
	
	float transaction(float amount);
}
