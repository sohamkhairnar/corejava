package com.gvacharya.interfacedemo.assignmenttwo.maintypeofnumber;

import com.gvacharya.interfacedemo.assignmenttwo.typeofnumber.TypeOfNumber;

public class MainTypeOfNumber {

	public static void main(String[] args) {
		
		TypeOfNumber checkArmstrongNumber = num -> {
		
		};
		
	}
}
