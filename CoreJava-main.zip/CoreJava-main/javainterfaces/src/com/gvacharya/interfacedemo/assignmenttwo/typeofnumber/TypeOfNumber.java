package com.gvacharya.interfacedemo.assignmenttwo.typeofnumber;

public interface TypeOfNumber {

	void checkNumber(int no);
}
