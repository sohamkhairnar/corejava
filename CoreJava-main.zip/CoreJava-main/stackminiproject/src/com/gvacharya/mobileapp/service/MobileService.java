package com.gvacharya.mobileapp.service;

public class MobileService {

}
