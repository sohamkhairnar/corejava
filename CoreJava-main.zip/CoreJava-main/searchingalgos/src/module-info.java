/**
 * 
 */
/**
 * 
 */
module searchingalgos {
}