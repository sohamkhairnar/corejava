package com.gvacharya.controlstatements;

public class ControlStatements {

	private boolean x ;
	
	public ControlStatements() {
		
	}
	
	public ControlStatements(boolean x) {
		
	}
	
	public boolean setx(boolean x) {
		
	}
}
