/**
 * 
 */
/**
 * 
 */
module reversestringprogram {
}