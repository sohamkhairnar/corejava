package com.primitivedtype.primitivedatatype;

public class Literals {
	
	public static void main(String[] args) {
		 byte byteVariable = 1_00; //100 are same
		 System.out.println(byteVariable);
		 short shortVariable = 32_000;
		 int intVariable = 2903841;
		 long longVariable = 1324983L;
		 
		 float floatVariable = 123.456F;
		 double doubleVariable = 1.23_431e4D;
		 
		 char charVariable = 'A';
		 char charVariable1 = 120; //ASCI value
		 char charVariable2 = '\u0000';
		 
		 boolean booleanVariable = true;
		 
		 String stringVariable = "Sequence of characters";
		 
		 String stringVariable1 = null;
	}
}
