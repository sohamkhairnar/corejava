package com.gvacharya.finalkeyword;

public class FinalKeyWord {

	// mutable and non-mutable
	// naming convention - CONSTANT_VARIABLE
	// final keyword is a modifier similar to static.
	// it is used to create a constant variable,method or class.
	// final method can not be overided. restricts method overloading concept.
	// final class. restricts inheritance concept.
	
	public static void main(String[] args) {
		
		final int var1 = 3;
		System.out.println(var1);
		
	}
}
