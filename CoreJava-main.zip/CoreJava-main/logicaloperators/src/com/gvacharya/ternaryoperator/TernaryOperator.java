package com.gvacharya.ternaryoperator;

public class TernaryOperator {
	
}
