/**
 * 
 */
/**
 * 
 */
module streamapi {
}