package com.gvacharya.accessmodifier.demo;

public class Parent {

	public void display() {
		System.out.println("Parent");
	}
}
// instance variable/constructor/method ke charo 
// access modifier user kar sakte hain .
