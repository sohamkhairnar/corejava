package com.gvacharya.swaptwonumbers;

public class SwapTwoNumbersMain {
	public static void main(String[] args) {
		SwapTwoNumbers swaptwonumber = new SwapTwoNumbers(10,20);
		
		swaptwonumber.numbersBeforeSwap();
		swaptwonumber.swapTwoNumbersUsingThirdVariable();
		swaptwonumber.swapTwoNumbersWithoutUsingThirdVariable();
	}
}
