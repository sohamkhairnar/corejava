/**
 * 
 */
/**
 * 
 */
module logicalprograms {
}