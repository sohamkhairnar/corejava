package com.gvacharya.printsumofevenandodd;

public class PrintSumOddEven {

	public static void main(String[] args) {
		
		PrintSumOfEvenAndOdd PrintSumOddEven = new PrintSumOfEvenAndOdd();
		
		PrintSumOddEven.sumOddEven(1,10);
		
		
	}
}
