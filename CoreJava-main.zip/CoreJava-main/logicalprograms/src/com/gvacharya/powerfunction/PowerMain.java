package com.gvacharya.powerfunction;

public class PowerMain {
	
	public static void main(String[] args) {
		
		Power pow = new Power(2,3);
		
		int result = pow.power();
		System.out.println(result);
		
	}
	
	
	
}
