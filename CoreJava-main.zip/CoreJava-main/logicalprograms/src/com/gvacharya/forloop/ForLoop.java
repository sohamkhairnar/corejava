package com.gvacharya.forloop;

public class ForLoop {

	public static void main(String[] args) {
		
		int i;
		int n = 2;
		// traditional for loop
		for (i=1;i<=10;i++) {
			System.out.println(n + "*" + i + "=" + (n*i));
		}
	}		
}
