/**
 * 
 */
/**
 * 
 */
module binarysearchproblems {
}