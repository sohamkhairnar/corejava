package com.gvacharya.messagedecoderprogram;

public class MessageDecoderMain {

	public static void main(String[] args) {
		
		MessageDecoder decoder = new MessageDecoder("122djg2");
		
		decoder.decoder();
		
		
	}
}
