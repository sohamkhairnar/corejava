package com.gvacharya.staticdemo;

public class StaticDemo {
	
	public static long pincode;
	
	public long pincode1;
	
	public StaticDemo() {
		
	}
	
}
