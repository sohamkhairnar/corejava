/**
 * 
 */
/**
 * 
 */
module staticmethodusecase {
}