package com.gvacharya.staticmethod;

public class StaticMethodMain {

	public static void main(String[] args) {
		
		StaticMethod.MainMethod(5, 6);
	}
}
