package com.gvacharya.staticmethod;

public class StaticMethod {
	
	public static void MainMethod(int var1, int var2) {
		
		System.out.println(var1+var2);
	}
}
// reference object is create within static method to call method.