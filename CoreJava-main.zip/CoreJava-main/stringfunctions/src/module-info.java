/**
 * 
 */
/**
 * 
 */
module stringfunctions {
}