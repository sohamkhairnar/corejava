/**
 * 
 */
/**
 * 
 */
module javacollections {
}