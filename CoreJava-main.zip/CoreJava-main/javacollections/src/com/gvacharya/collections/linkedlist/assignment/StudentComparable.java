package com.gvacharya.collections.linkedlist.assignment;

public class StudentComparable {

}
