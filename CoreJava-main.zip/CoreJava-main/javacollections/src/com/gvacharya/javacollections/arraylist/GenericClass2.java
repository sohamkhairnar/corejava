package com.gvacharya.javacollections.arraylist;

public class GenericClass2 {

	private Integer number;

	

	public GenericClass2(Integer number) {
		super();
		this.number = number;
	}



	public Integer getNumber() {
		return number;
	}

	
	
}
