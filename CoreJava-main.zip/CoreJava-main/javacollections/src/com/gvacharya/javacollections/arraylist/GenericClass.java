package com.gvacharya.javacollections.arraylist;

public class GenericClass {

	public static void main(String[] args) {
		add(10,20);
		add(12,20);
		add(13,20);
		add(15,20);
		add(10,20);
		add(10,20);
		
		
	}
	
	public static void add(int num1,int num2) {
		System.out.println(num1+num2);
	}
}
