package com.gvacharya.generic.mobilebill.framework;

public interface Payable {

}
