/**
 * 
 */
/**
 * 
 */
module vowelcounterprogram {
}