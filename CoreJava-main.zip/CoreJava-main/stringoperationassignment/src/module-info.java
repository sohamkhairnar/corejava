/**
 * 
 */
/**
 * 
 */
module stringoperationassignment {
}