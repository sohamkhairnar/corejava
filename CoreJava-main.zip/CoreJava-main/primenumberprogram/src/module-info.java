/**
 * 
 */
/**
 * 
 */
module primenumberprogram {
}