/**
 * 
 */
/**
 * 
 */
module stringclass {
}